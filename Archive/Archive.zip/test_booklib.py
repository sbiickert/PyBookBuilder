#!/usr/bin/env python3

import os
import os.path
import booklib

# Parsing the list of books
book_db = booklib.BookDatabase('books.json')
name = os.path.join(book_db.books[0], booklib.BOOK_DATA)

# Parsing a book
ff_book = booklib.Book(name)
assert len(ff_book.chapters) == 9, "Expected nine chapters, got {}".format(len(ff_book.chapters))

# Parsing a chapter file
chapter_one = ff_book.chapters[1]
chapter_scenes = chapter_one.get_scenes()
assert len(chapter_scenes) == 2, "Expected two scenes, got {}".format(len(chapter_scenes))

# Reading scene header
library_scene = chapter_scenes[1]
print(library_scene.description)

# Compiling to Markdown
md_string = ff_book.compile()
assert len(md_string) > 0
exit(0)

# Saving a book
test_file_name = os.path.join(ff_book.path(), 'test_output_book.json')
ff_book.save_to_file(test_file_name)
test_book = booklib.Book(test_file_name)
assert ff_book == test_book
os.remove(test_file_name)

# Saving a chapter
test_file_name = os.path.join(chapter_one.path, "test_output_chapter.md")
original_file_name = chapter_one.file_name
chapter_one.file_name = test_file_name
chapter_scenes.reverse()
chapter_one.set_scenes(chapter_scenes)
reread_chapter_scenes = chapter_one.get_scenes()
assert chapter_scenes == reread_chapter_scenes
os.remove(test_file_name)
chapter_one.file_name = original_file_name

# Saving the book database
test_file_name = 'test_db.json'
book_db.save_to_file(test_file_name)
test_db = booklib.BookDatabase(test_file_name)
assert book_db == test_db
os.remove(test_file_name)

# Archive a book
archive_path = '/Users/sbiickert/Dropbox/OurFolder/Simon Writer/PyBookBuilder Archive'
zip_file = book_db.archive_book(0, archive_path)
assert zip_file is not None

# Move a book
orig_path = ff_book.path()
dest_path = '/Users/sbiickert/Temp/Test Book'
assert book_db.move_book(orig_path, dest_path, archive_path)

# Move it back
os.mkdir(orig_path) # Was deleted during move
assert book_db.move_book(dest_path, orig_path, archive_path)
