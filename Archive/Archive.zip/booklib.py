#!/usr/bin/env python3

""" Business objects for PyBookBuilder """

import json
import os.path
import logging
import shutil
import datetime
import random
import string
import weakref

from typing import Optional, List, Dict, Any, Tuple
from distutils.dir_util import copy_tree

BOOK_DATA = 'book_data.json'

logging.basicConfig(filename='bookbuilder.log', level=logging.DEBUG)


class Scene():
    """ Represents a scene from the book """

    def __init__(self, content: Tuple[str, str] = None):
        """
        Initializes the :class:`booklib.Scene`.
        """

        self.description = ""
        self.location = ""
        self.pov = ""
        self.status = ""
        self.characters: List[str] = []

        self.start_line_number = 0
        self.body_text = ""

        self.__chapter_refs = None

        if content is not None:
            self.read_header(content[0])
            self.body_text = content[1].lstrip().rstrip()

    def get_chapter(self):
        # pylint: disable=not-callable
        if self.__chapter_ref is not None:
            return self.__chapter_ref()
        return None

    def set_chapter(self, chapter):
        if chapter is None:
            self.__chapter_ref = None
        else:
            self.__chapter_ref = weakref.ref(chapter)

    def word_count(self):
        """Splits body_text and returns the length"""
        return len(self.body_text.split())

    def read_header(self, json_text: str):
        """
        Parses the passed scene JSON header and populates the member variables.
        :param json_text: the scene header text to parse
        """
        try:
            header_dict = json.loads(json_text)
            self.description = header_dict['description']
            self.location = header_dict['location']
            self.pov = header_dict['pov']
            self.status = header_dict['status']
            self.characters = header_dict['characters']
        except json.decoder.JSONDecodeError:
            logging.info("Could not parse JSON from scene header text %s", json_text)
        except KeyError:
            logging.info("Missing header key.")

    def write_header(self) -> str:
        """
        Outputs the :class:`booklib.Scene` ivars to the JSON header format.
        """
        header_dict: Dict[str, Any] = {}
        header_dict['description'] = self.description
        header_dict['location'] = self.location
        header_dict['pov'] = self.pov
        header_dict['status'] = self.status
        header_dict['characters'] = self.characters
        json_text = json.dumps(header_dict, indent=2)
        return json_text

    def __eq__(self, other):
        """ Checks for equality of all ivars """
        if other is None:
            return False
        if not isinstance(other, Scene):
            return False
        return self.description == other.description and \
               self.location == other.location and \
               self.pov == other.pov and \
               self.characters == other.characters and \
               self.body_text == other.body_text


class Chapter():
    """ Represents a collection of scenes with a title and subtitle """
    def __init__(self):
        """ Initializes title, subtitle, path and scene file names to empty """
        self.title = ""
        self.subtitle = ""
        self.file_name = ""
        self.number = 0
        self.__book_ref = None

    def get_book(self):
        # pylint: disable=not-callable
        if self.__book_ref is not None:
            return self.__book_ref()
        return None

    def set_book(self, book):
        if book is None:
            self.__book_ref = None
        else:
            self.__book_ref = weakref.ref(book)

    def set_initial_file_name(self, file_name: Optional[str] = None):
        if file_name is None:
            file_name = "_".join(self.title.split())
        # Create a random set of letters as a suffix
        suffix = ''.join(random.sample(string.ascii_uppercase,4))
        file_name = f'{file_name}_{suffix}.md'
        self.file_name = os.path.join(self.get_book().path(), file_name)

    def word_count(self) -> int:
        """ Sums the word counts of all the Scenes. """
        w_count = 0
        for scene in self.get_scenes():
            w_count = w_count + scene.word_count()
        return w_count

    def get_scenes(self) -> List[Scene]:
        """
        Opens the chapter file and returns parsed content
        :return: The parsed Scene objects
        """
        all_scenes: List[Scene] = []
        book = self.get_book()
        if book is None:
            return all_scenes
        chapter_file_name = os.path.join(book.path(), self.file_name)
        with open(chapter_file_name) as chapter_file:
            chapter_text = chapter_file.read()
        # Scenes are delimited by a code block (starts and ends with ```)
        split_chapter = chapter_text.split('```')
        #[0]: empty (before first ````)
        # odd: JSON headers
        # even: Markdown text
        line_count = 0
        for idx in range(1, len(split_chapter) - 1, 2):
            content = (split_chapter[idx], split_chapter[idx + 1])
            scene = Scene(content)
            scene.set_chapter(self)
            scene.start_line_number = line_count
            all_scenes.append(scene)
            line_count = line_count + content[0].count('\n') + content[1].count('\n')
        return all_scenes

    def set_scenes(self, scenes: List[Scene]):
        """
        Writes the set of scenes to the chapter file.
        """
        book = self.get_book()
        if book is None:
            logging.error("set_scenes: __book_ref of chapter is not set")
            return
        chapter_file_name = os.path.join(book.path(), self.file_name)
        with open(chapter_file_name, "w") as chapter_file:
            for scene in scenes:
                chapter_file.write('\n'.join(['```', scene.write_header(), '```']))
                chapter_file.write('\n\n')
                chapter_file.write(scene.body_text)
                chapter_file.write('\n\n')
    
    def reorder_scene(self, scene: Scene, earlier: bool):
        all_scenes = self.get_scenes()
        idx = -1
        for scene_index, a_scene in enumerate(all_scenes):
            if scene == a_scene:
                idx = scene_index
                break
        if idx >= 0:
            if earlier and idx > 0:
                all_scenes[:] = all_scenes[0:idx-1] + all_scenes[idx:idx+1] + all_scenes[idx-1:idx] + all_scenes[idx+1:]
            elif not earlier and idx < len(all_scenes):
                all_scenes[:] = all_scenes[0:idx] + all_scenes[idx+1:idx+2] + all_scenes[idx:idx+1] + all_scenes[idx+2:]
            self.set_scenes(all_scenes)

    def replace_scene(self, old_scene: Scene, new_scene: Scene):
        all_scenes = self.get_scenes()
        idx = -1
        for scene_index, a_scene in enumerate(all_scenes):
            if old_scene == a_scene:
                idx = scene_index
                break
        if idx >= 0:
            all_scenes[:] = all_scenes[0:idx] + [new_scene] + all_scenes[idx+1:]
            self.set_scenes(all_scenes)

    def from_dict(self, ch_dict: Dict[str, Any]) -> None:
        """
        Populates self with the contents of ch_dict read from JSON book_data file
        """
        book = self.get_book()
        if book is None:
            logging.error("from_dict: __book_ref of chapter is not set")
            return
        self.title = ch_dict['title']
        self.subtitle = ch_dict['subtitle']
        chapter_file = os.path.join(book.path(), ch_dict['file'])
        if os.path.isfile(chapter_file):
            self.file_name = chapter_file
        else:
            logging.warning("Chapter file %s does not exist", chapter_file)

    def to_dict(self):
        """
        Writes self to a dictionary data structure for writing to a book_data file
        """
        ch_dict: Dict[str, Any] = {}
        ch_dict['title'] = self.title
        ch_dict['subtitle'] = self.subtitle
        ch_dict['file'] = os.path.basename(self.file_name)
        return ch_dict

    def compile(self) -> List[str]:
        """Combines all scenes into a list of Markdown strings."""
        markdown_strings: List[str] = ['\\newpage', f'## Chapter {self.number}: {self.title}']
        if len(self.subtitle.strip()) > 0:
            markdown_strings.append(f'### {self.subtitle}')
        for scene in self.get_scenes():
            markdown_strings.append(scene.body_text)
            markdown_strings.append('***')
        # Remove the last scene break, b/c we've added one too many
        markdown_strings.pop()
        return markdown_strings

    def __eq__(self, other):
        """ Checks for equality of all ivars """
        if other is None:
            return False
        if not isinstance(other, Chapter):
            return False
        return self.title == other.title and \
               self.subtitle == other.subtitle and \
               self.file_name == other.file_name


class Book():
    """ Metadata about a book and an ordered list of chapters."""
    # pylint: disable=too-many-instance-attributes
    def __init__(self, file_name=None):
        """
        Initializes all ivars, then parses the named file if passed.

        :param file_name: Absolute or relative file name of book_data JSON file.
        :type file_name: str, optional
        """
        self.__file_name = ""

        self.title = ""
        self.subtitle = ""
        self.author = ""
        self.year = 0
        self.keywords = []
        self.genres = []
        self.chapters = []

        if file_name is not None:
            self.__file_name = file_name
            self.open_file(file_name)

    def path(self) -> str:
        """
        Convenience method that returns the path part of the book_data file name.
        :return: Book data file path
        :rtype: str
        """
        return os.path.dirname(self.__file_name)

    @classmethod
    def build_book_file_name(cls, book_path: str) -> str:
        return os.path.join(book_path, BOOK_DATA)

    @classmethod
    def is_book_path_valid(cls, book_path: str) -> bool:
        """
        Determines if a path points to a directory with a book data file in it.
        :param book_path: Absolute or relative path to directory.
        :type book_path: str
        :return: True if valid.
        :rtype: bool
        """
        if os.path.isdir(str(book_path)):
            book_data_file = Book.build_book_file_name(str(book_path))
            if os.path.isfile(book_data_file):
                # ok
                return True
            logging.info("%s is missing from directory %s", BOOK_DATA, book_path)
        else:
            logging.info("Directory %s doesn't exist", book_path)
        return False

    def get_characters(self) -> List[str]:
        characters: List[str] = []
        for chapter in self.chapters:
            for scene in chapter.get_scenes():
                characters.extend(scene.characters)
                characters.append(scene.pov)
        unique_characters = list(set(characters))
        unique_characters.remove("") # Can happen easily
        sorted_by_count = sorted(unique_characters, key=lambda x: characters.count(x), reverse=True)
        return sorted_by_count

    def append_chapter(self, new_chapter: Chapter):
        open(new_chapter.file_name, 'w').close()
        self.chapters.append(new_chapter)
        self.save_to_file()
    
    def reorder_chapter(self, chapter: Chapter, earlier: bool):
        idx = self.chapters.index(chapter)
        if earlier and idx > 0:
            self.chapters[:] = self.chapters[0:idx-1] + self.chapters[idx:idx+1] + self.chapters[idx-1:idx] + self.chapters[idx+1:]
        elif not earlier and idx < len(self.chapters):
            self.chapters[:] = self.chapters[0:idx] + self.chapters[idx+1:idx+2] + self.chapters[idx:idx+1] + self.chapters[idx+2:]
        self.save_to_file()

    def delete_chapter(self, chapter_to_delete: Chapter):
        os.remove(chapter_to_delete.file_name)
        self.chapters.remove(chapter_to_delete)
        self.save_to_file()

    def __renumber_chapters(self):
        for (idx, chapter) in enumerate(self.chapters):
            chapter.number = idx

    def open_file(self, file_name: str):
        """
        Opens the specified file and parses JSON text. Populates self if successful.
        :param file_name: The absolute or relative book_data file name
        :type file_name: str
        """
        book_data = None
        try:
            with open(file_name) as book_file:
                json_text = book_file.read()
                book_data = json.loads(json_text)
        except FileNotFoundError:
            logging.error("Could not open book data file %s", file_name)
        except json.decoder.JSONDecodeError:
            logging.error("Could not parse JSON from book data file %s", json_text)
        if book_data is not None:
            self.from_dict(book_data)

    def from_dict(self, book_dict: Dict[str, Any]):
        """
        Populates self with the contents of book_dict read from JSON book_data file
        """
        self.title = book_dict['title']
        self.subtitle = book_dict['subtitle']
        self.author = book_dict['author']
        self.year = book_dict['year']
        self.keywords = list(book_dict['keywords'])
        self.genres = list(book_dict['genres'])
        self.chapters = []
        for ch_data in book_dict['chapters']:
            chapter = Chapter()
            chapter.set_book(self)
            chapter.from_dict(ch_data)
            self.chapters.append(chapter)
        self.__renumber_chapters()

    def save_to_file(self, file_name: Optional[str] = None):
        """
        Writes self to a book_data file as JSON.
        File is overwritten if it exists.
        If no file name is passed, the content is written back to the file it was read from.
        :param file_name: The book_data file to write to.
        :type file_name: str, optional
        """
        if file_name is None:
            # Save
            file_name = self.__file_name
        else:
            # Save As
            self.__file_name = file_name
        book_dict = self.to_dict()
        json_text = json.dumps(book_dict)
        with open(file_name, "w") as books_file:
            books_file.write(json_text)
        self.__renumber_chapters()

    def to_dict(self) -> Dict[str, Any]:
        """Writes self to a dictionary data structure."""
        book_dict = {}
        book_dict['title'] = self.title
        book_dict['subtitle'] = self.subtitle
        book_dict['author'] = self.author
        book_dict['year'] = self.year
        book_dict['keywords'] = self.keywords
        book_dict['genres'] = self.genres
        book_dict['chapters'] = []
        for chapter in self.chapters:
            book_dict['chapters'].append(chapter.to_dict())
        return book_dict

    def compile(self) -> str:
        """
        Combines all chapters into a single Markdown string.
        """
        markdown_content = [f'# {self.title}',
                            f'{self.subtitle}',
                            f'©{self.author}, {self.year}']
        for chapter in self.chapters:
            markdown_content.extend(chapter.compile())

        return "\n\n".join(markdown_content)

    def __eq__(self, other):
        """ Checks for equality by exporting to dict and comparing """
        if isinstance(other, Book):
            self_dict = self.to_dict()
            other_dict = other.to_dict()
            return self_dict == other_dict
        return False


class BookDatabase():
    """
    Encapsulates interactions with books.json
    """
    def __init__(self, file_name=None):
        """
        Initializes books list. If file name is passed, it is parsed an populates books list.
        """
        self.books = []
        self.__file_name = None
        if file_name is not None:
            self.open_file(file_name)

    def is_index_valid(self, index: int) -> bool:
        if index < 0:
            return False
        if index >= len(self.books):
            return False
        return True

    def index_of_book(self, book: Book) -> Optional[int]:
        try:
            book_index = self.books.index(book.path())
        except ValueError:
            return None
        return book_index

    def book(self, index: int) -> Optional[Book]:
        if self.is_index_valid(index):
            return Book(Book.build_book_file_name(self.books[index]))
        return None

    def all_books(self) -> List[Book]:
        ret_list = []
        for book_path in self.books:
            ret_list.append(Book(Book.build_book_file_name(book_path)))
        return ret_list
        
    def add_book(self, book_path: str, insert_first: bool = False):
        """
        Adds a book to the list.
        Checks that the book path is a directory with a book data file in it.
        :param book_path: Path to directory with book data.
        :type book_path: str
        :param insert_first: Inserts to the front of the book list if True.
        :type insert_first: bool, optional
        """
        if Book.is_book_path_valid(book_path):
            if insert_first:
                self.books.insert(0, book_path)
            else:
                self.books.append(book_path)
            # DB is changed, save file
            self.save_to_file()

    def remove_book(self, index: int, archive_path: str):
        """
        Removes a book from the list. Archives the contents before removing directory.
        :param index: Index of the book to remove.
        :type index: int
        :param archive_path: Directory path to save the archive file to.
        :type archive_path: str
        """
        if self.is_index_valid(index):
            book_path = self.books[index]
            if self.archive_book(index, archive_path) is not None:
                shutil.rmtree(book_path)
                del self.books[index]
                # DB is changed, save file
                self.save_to_file()

    def move_book(self, current_book_path:str, new_book_path: str, archive_path: str) -> bool:
        # Check if current_book_path is a valid book
        try:
            current_index = self.books.index(current_book_path)
        except ValueError:
            logging.error("move_book: could not find book at %s", current_book_path)
            return False
       # Make sure new_book_path is NOT a valid book (i.e. already exists)
        try:
            _ = self.books.index(new_book_path)
            logging.error("move_book: a book already exists at %s", new_book_path)
            return False
        except ValueError:
            pass
        # Check that the new location exists
        if os.path.isdir(new_book_path) == False:
            # Create the directory
            os.mkdir(new_book_path)
        # Archive the book before doing anything destructive
        if self.archive_book(current_index, archive_path) is None:
             logging.error("move_book: could not archive book at %s. Stopping.", current_book_path)
             return False
        # Copy the book directory contents
        copy_tree(current_book_path, new_book_path)
        # Remove the current directory
        shutil.rmtree(current_book_path)
        # Update the books list
        del self.books[current_index]
        self.books.insert(0, new_book_path)
        # DB is changed, save file
        self.save_to_file()
        return True

    def archive_book(self, index: int, archive_path: str) -> Optional[str]:
        """
        Zips the contents of the book directory and saves it to the archive.
        :param index: Index of the book to archive.
        :type index: int
        :param archive_path: Directory path to save the archive file to.
        :type archive_path: str
        :return: Archive file name if the archive was successful.
        :rtype: str, optional
        """
        if self.is_index_valid(index):
            book_path = self.books[index]
            if os.path.isdir(str(archive_path)):
                time_stamp = datetime.datetime.now().strftime("_%Y-%m-%d-%H-%M")
                archive_name = os.path.join(archive_path, os.path.basename(book_path) + time_stamp)
                created_archive = shutil.make_archive(archive_name, 'zip', book_path)
                logging.info("Archive created %s", created_archive)
                return archive_name + '.zip'
        return None

    def move_book_to_most_recent(self, idx: int):
        """Convenience method to rearrange a book to the front of the list"""
        if self.is_index_valid(idx):
            self.books[:] = self.books[idx:idx+1] + self.books[0:idx] + self.books[idx+1:]
            # DB is changed, save file
            self.save_to_file()

    def open_file(self, file_name: str):
        """
        Opens specified file and populates the books list.
        File is expected to be JSON with a "books" key with a list of directory names.
        Does a check to see if each directory appears to be a valid book.
        :param file_name: The books database JSON file.
        :type file_name: str
        """
        self.books = []
        self.__file_name = file_name
        book_path_list: List[str] = []
        try:
            with open(file_name) as books_file:
                json_text = books_file.read()
                db_dict = json.loads(json_text)
                book_path_list = list(db_dict["books"])
        except FileNotFoundError:
            logging.debug("Could not open file %s", file_name)
        for book_path in book_path_list:
            self.add_book(book_path)

    def save_to_file(self, file_name: Optional[str] = None):
        """
        Writes the list of books to the books database file
        """
        if file_name is None:
            # Save
            file_name = self.__file_name
        else:
            # Save As
            self.__file_name = file_name
        db_dict = {}
        db_dict["books"] = self.books
        json_text = json.dumps(db_dict)
        with open(file_name, "w") as books_file:
            books_file.write(json_text)

    def __eq__(self, other):
        """ Check for equality of book list. """
        return self.books == other.books

if __name__ == '__main__':
    print("booklib.py is not to be called directly.")
